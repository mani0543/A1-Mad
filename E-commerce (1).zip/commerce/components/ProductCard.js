import React from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet } from 'react-native';
import { Star } from 'lucide-react-native';

export default function ProductCard({ product, onAddToCart }) {
  return (
    <View style={styles.card}>
      <Image source={{ uri: product.image }} style={styles.cardImage} />
      <View style={styles.cardContent}>
        <View style={styles.cardHeader}>
          <Text style={styles.cardTitle}>{product.name}</Text>
          <Text style={styles.cardPrice}>${product.price.toFixed(2)}</Text>
        </View>
        <View style={styles.ratingContainer}>
          <Star size={16} color="#FBBF24" fill="#FBBF24" />
          <Text style={styles.ratingText}>
            {product.rating} ({product.reviews} reviews)
          </Text>
        </View>
        <TouchableOpacity style={styles.addToCartButton} onPress={() => onAddToCart(product)}>
          <Text style={styles.addToCartButtonText}>Add to Cart</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    width: '48%', // Two cards per row
    backgroundColor: '#FFF',
    borderRadius: 12,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3, // For Android shadow
  },
  cardImage: {
    width: '100%',
    height: 150,
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
    resizeMode: 'cover',
  },
  cardContent: {
    padding: 12,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    flexShrink: 1, // Prevents text overflow
  },
  cardPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#3B82F6',
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  ratingText: {
    fontSize: 14,
    color: '#666',
    marginLeft: 4,
  },
  addToCartButton: {
    backgroundColor: '#3B82F6',
    borderRadius: 8,
    paddingVertical: 10,
    alignItems: 'center',
  },
  addToCartButtonText: {
    color: '#FFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
});