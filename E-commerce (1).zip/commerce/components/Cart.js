import React from 'react';
import { View, Text, TouchableOpacity, Image, ScrollView, StyleSheet } from 'react-native';
import { ShoppingCart, X } from 'lucide-react-native';

export default function Cart({ items, onUpdateQuantity, onRemoveItem, isOpen, onClose, navigation }) {
  const total = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  const handleCheckout = () => {
    console.log('Checkout button pressed'); // Debug log
    onClose(); // Close the cart modal
    navigation.navigate('Checkout', { total }); // Navigate to CheckoutScreen with total
  };

  if (!isOpen) return null;

  return (
    <View style={styles.overlay}>
      <View style={styles.cartContainer}>
        {/* Cart Header */}
        <View style={styles.cartHeader}>
          <View style={styles.cartHeaderTitle}>
            <ShoppingCart size={24} color="#333" />
            <Text style={styles.cartHeaderText}>Your Cart</Text>
          </View>
          <TouchableOpacity onPress={onClose}>
            <X size={24} color="#666" />
          </TouchableOpacity>
        </View>

        {/* Cart Items */}
        <ScrollView style={styles.cartItems}>
          {items.map((item) => (
            <View key={item.product.id} style={styles.cartItem}>
              <Image source={{ uri: item.product.image }} style={styles.cartItemImage} />
              <View style={styles.cartItemDetails}>
                <Text style={styles.cartItemName}>{item.product.name}</Text>
                <Text style={styles.cartItemPrice}>${item.product.price.toFixed(2)}</Text>
                <View style={styles.cartItemActions}>
                  <TouchableOpacity
                    onPress={() => onUpdateQuantity(item.product.id, Math.max(0, item.quantity - 1))}
                    style={styles.cartItemButton}
                  >
                    <Text style={styles.cartItemButtonText}>-</Text>
                  </TouchableOpacity>
                  <Text style={styles.cartItemQuantity}>{item.quantity}</Text>
                  <TouchableOpacity
                    onPress={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                    style={styles.cartItemButton}
                  >
                    <Text style={styles.cartItemButtonText}>+</Text>
                  </TouchableOpacity>
                </View>
              </View>
              <TouchableOpacity
                onPress={() => onRemoveItem(item.product.id)}
                style={styles.cartItemRemove}
              >
                <X size={20} color="#EF4444" />
              </TouchableOpacity>
            </View>
          ))}
        </ScrollView>

        {/* Cart Footer */}
        <View style={styles.cartFooter}>
          <View style={styles.cartTotal}>
            <Text style={styles.cartTotalText}>Total:</Text>
            <Text style={styles.cartTotalPrice}>${total.toFixed(2)}</Text>
          </View>
          <TouchableOpacity style={styles.checkoutButton} onPress={handleCheckout}>
            <Text style={styles.checkoutButtonText}>Checkout</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  cartContainer: {
    backgroundColor: '#FFF',
    height: '80%',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 16,
  },
  cartHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
    paddingBottom: 16,
  },
  cartHeaderTitle: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  cartHeaderText: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 8,
  },
  cartItems: {
    flex: 1,
    marginTop: 16,
  },
  cartItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  cartItemImage: {
    width: 80,
    height: 80,
    borderRadius: 8,
    marginRight: 16,
  },
  cartItemDetails: {
    flex: 1,
  },
  cartItemName: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  cartItemPrice: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  cartItemActions: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },
  cartItemButton: {
    backgroundColor: '#F3F4F6',
    borderRadius: 8,
    padding: 8,
  },
  cartItemButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  cartItemQuantity: {
    marginHorizontal: 16,
    fontSize: 16,
  },
  cartItemRemove: {
    padding: 8,
  },
  cartFooter: {
    borderTopWidth: 1,
    borderTopColor: '#E5E7EB',
    paddingTop: 16,
  },
  cartTotal: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  cartTotalText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  cartTotalPrice: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  checkoutButton: {
    backgroundColor: '#3B82F6',
    borderRadius: 8,
    padding: 16,
    alignItems: 'center',
  },
  checkoutButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});