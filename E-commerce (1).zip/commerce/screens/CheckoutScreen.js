import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

export function CheckoutScreen({ route, navigation }) {
  const { total } = route.params; // Total amount passed from Cart

  const handlePlaceOrder = () => {
    // Navigate to the Success screen
    navigation.navigate('Success');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Checkout</Text>
      <Text style={styles.total}>Total: ${total.toFixed(2)}</Text>

      {/* Payment Method Section */}
      <View style={styles.paymentSection}>
        <Text style={styles.paymentTitle}>Select Payment Method</Text>
        <TouchableOpacity style={styles.paymentMethod}>
          <Text style={styles.paymentMethodText}>Credit Card</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.paymentMethod}>
          <Text style={styles.paymentMethodText}>PayPal</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.paymentMethod}>
          <Text style={styles.paymentMethodText}>Google Pay</Text>
        </TouchableOpacity>
      </View>

      {/* Place Order Button */}
      <TouchableOpacity style={styles.button} onPress={handlePlaceOrder}>
        <Text style={styles.buttonText}>Place Order</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5F7FA',
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
    color: '#333',
  },
  total: {
    fontSize: 18,
    color: '#666',
    marginBottom: 32,
  },
  paymentSection: {
    width: '100%',
    marginBottom: 32,
  },
  paymentTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
    color: '#333',
  },
  paymentMethod: {
    backgroundColor: '#FFF',
    padding: 16,
    borderRadius: 8,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  paymentMethodText: {
    fontSize: 16,
    color: '#333',
  },
  button: {
    backgroundColor: '#3B82F6',
    borderRadius: 8,
    padding: 16,
    width: '100%',
    alignItems: 'center',
  },
  buttonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});